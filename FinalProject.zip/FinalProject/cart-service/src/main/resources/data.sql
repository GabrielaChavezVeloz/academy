insert into carts (id_course, id_user, name_course, is_active, price) 
values (1, 1, "java for beginners", 1, 100);

insert into carts (id_course, id_user, name_course, is_active, price) 
values (3, 1, "java web", 1, 200);