package com.ecommerce.udemy.cartservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
