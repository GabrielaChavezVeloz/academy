insert into areas (area) values ("Development");
insert into areas (area) values ("Design");
insert into areas (area) values ("Testing");
insert into areas (area) values ("Management");

insert into types (type) values("student");
insert into types (type) values("professional");
insert into types (type) values("admin");

insert into roles (role) values("developer");
insert into roles (role) values("tester");
insert into roles (role) values("leader");
insert into roles (role) values("designer");

